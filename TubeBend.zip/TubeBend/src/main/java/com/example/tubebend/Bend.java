package com.example.tubebend;

import javafx.scene.control.TreeItem;

import java.util.ArrayList;

public class Bend {

    private ArrayList<Step> steps = new ArrayList<Step>();
    private String name = "";
    private String orig_name = "";
    private double y_main = 0;
    private double b_main = 0;
    private double c_main = 0;
    private double y_abs = 0;
    private double b_abs = 0;
    private double y_main_corr = 0;
    private double b_main_corr = 0;
    private double c_main_corr = 0;
    private char type;


    public Bend(String name, char type){
        this.type = type;
        this.orig_name = name;
        fillSteps();
    }

    private void fillSteps() {
        switch (type){
            case 'h' ->{
                steps.add(new PrimaryStep('X',0,0,true,100,true,0,0,false,""));
                steps.add(new PrimaryStep('Z',0,0,true,100,true,0,0,false,""));
                steps.add(new PrimaryStep('X',0,0,false,100,true,0,0,false,""));
            }
            case 'd' ->{
                steps.add(new PrimaryStep('X',0,0,true,100,true,0,0,false,""));
                steps.add(new PrimaryStep('Z',0,0,false,100,true,0,0,false,""));
                steps.add(new PrimaryStep('X',0,0,false,100,true,0,0,false,""));
            }
            case 'o' ->{
                steps.add(new SecondaryStep('K',true,false,0,0,""));
                steps.add(new PrimaryStep('Y', 100,0,true, 100, true, 0, 0,true, ""));
                steps.add(new PrimaryStep('B', 10,0,false, 100, false, 0, 0,true, ""));
                steps.add(new SecondaryStep('T', true, false,0,0,""));
                steps.add(new SecondaryStep('K',false,false,0,0,""));
                steps.add(new PrimaryStep('C', 60,0,false, 100, false, 0, 0,true, "ohyb"));
                steps.add(new PrimaryStep('Y', 55,0,false, 100, false, 0, 0,false, "dobehnutie"));
                steps.add(new SecondaryStep('K',true,false,0,0,""));
                steps.add(new SecondaryStep('T', false, false,0,0,""));
                steps.add(new PrimaryStep('Y', 55,0,false, 100, false, 0, 0,false, "von z nastroja"));
                steps.add(new PrimaryStep('C', 0,0,true, 100, false, 0, 0,false, "navrat"));
            }
            case 'u' ->{
                steps.add(new SecondaryStep('K',true,false,0,0,""));
                steps.add(new PrimaryStep('Y', 100,0,true, 100, true, 0, 0,true, ""));
                steps.add(new PrimaryStep('B', 10,0,false, 100, false, 0, 0,true, ""));
                steps.add(new SecondaryStep('T', true, false,0,0,""));
                steps.add(new SecondaryStep('U',false,false,0,0,""));
                steps.add(new PrimaryStep('C', 60,0,false, 100, false, 0, 0,true, "ohyb"));
                steps.add(new SecondaryStep('U',true,false,0,0,""));
                steps.add(new SecondaryStep('T', false, false,0,0,""));
                steps.add(new PrimaryStep('Y', 55,0,false, 100, false, 0, 0,false, "von z nastroja"));
                steps.add(new PrimaryStep('C', 0,0,true, 100, false, 0, 0,false, "navrat"));
            }
            case 'k' ->{
                steps.add(new SecondaryStep('K',true,false,0,0,""));
                steps.add(new PrimaryStep('Y', 100,0,true, 100, true, 0, 0,true, ""));
                steps.add(new PrimaryStep('B', 10,0,false, 100, false, 0, 0,true, ""));
                steps.add(new SecondaryStep('T', true, false,0,0,""));
                steps.add(new SecondaryStep('K',false,false,0,0,""));
                steps.add(new PrimaryStep('Y', 100,0,true, 100, true, 0, 0,false, "navrat"));
                steps.add(new SecondaryStep('T', true, false,0,0,""));
                steps.add(new PrimaryStep('C', 60,0,false, 100, false, 0, 0,true, "ohyb"));
                steps.add(new SecondaryStep('T', false, false,0,0,""));
                steps.add(new PrimaryStep('C', 0,0,true, 100, false, 0, 0,false, "navrat"));
            }
        }

        actualize();

    }

    public void actualize(){
        getMainParameters();
        fixName();
    }

    private void getMainParameters() {
        for(Step s:steps){
            if(s instanceof PrimaryStep && s.isMainStep()){
                switch (s.getAxis()){
                    case 'Y':
                        y_main = s.getPos();
                        y_main_corr = s.getCorr();
                        break;
                    case 'B':
                        b_main = s.getPos();
                        b_main_corr = s.getCorr();
                        break;
                    case 'C':
                        c_main = s.getPos();
                        c_main_corr = s.getCorr();
                        break;
                }
            }
        }
    }

    private void fixName() {
        this.name = orig_name;
        for(Step s:steps){
            if(s.isMainStep()) this.name += " " + s.getAxis() + " " + (s.getPos()+s.getCorr());
        }
    }

    @Override

    public String toString() {
        return name;
    }

    public ArrayList<Step> getSteps() {
        return steps;
    }

    public void setSteps(ArrayList<Step> steps) {
        this.steps = steps;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getY_main() {
        return y_main;
    }

    public void setY_main(double y_main) {
        this.y_main = y_main;
    }

    public double getB_main() {
        return b_main;
    }

    public void setB_main(double b_main) {
        this.b_main = b_main;
    }

    public double getC_main() {
        return c_main;
    }

    public void setC_main(double c_main) {
        this.c_main = c_main;
    }

    public double getY_main_corr() {
        return y_main_corr;
    }

    public void setY_main_corr(double y_main_corr) {
        this.y_main_corr = y_main_corr;
    }

    public double getB_main_corr() {
        return b_main_corr;
    }

    public void setB_main_corr(double b_main_corr) {
        this.b_main_corr = b_main_corr;
    }

    public double getC_main_corr() {
        return c_main_corr;
    }

    public void setC_main_corr(double c_main_corr) {
        this.c_main_corr = c_main_corr;
    }

    public double getY_abs() {
        return y_abs;
    }

    public void setY_abs(double y_abs) {
        this.y_abs = y_abs;
    }

    public double getB_abs() {
        return b_abs;
    }

    public void setB_abs(double b_abs) {
        this.b_abs = b_abs;
    }
}
