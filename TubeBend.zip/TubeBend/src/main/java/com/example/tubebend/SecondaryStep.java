package com.example.tubebend;

public class SecondaryStep extends Step{

    private boolean isStop;
    private boolean isXControlled;
    private boolean isClampClosed;
    private boolean tClose;
    private boolean isT1;
    private boolean isT2;


    public SecondaryStep(char axis, boolean value, boolean noWait, double waitBefore, double waitAfter, String note) {
        super(axis, noWait, waitBefore, waitAfter, note);
        switch (axis){
            case 'U':
                isXControlled = value;
                isStop = false;
                isT1 = false;
                isT2 = false;
                isClampClosed = false;
                break;
            case 'T':
                isT1 = true;
                isT2 = true;
                tClose = value;
                isStop = false;
                isXControlled = false;
                isClampClosed = false;
                break;
            case 'S':
                isStop = value;
                isXControlled = false;
                isT1 = false;
                isT2 = false;
                isClampClosed = false;
                break;
            case 'K':
                isClampClosed = value;
                isStop = false;
                isXControlled = false;
                isT1 = false;
                isT2 = false;
                break;

        }
    }

    public boolean isStop() {
        return isStop;
    }

    public void setStop(boolean stop) {
        isStop = stop;
    }

    public boolean isT1() {
        return isT1;
    }

    public void setT1(boolean t1) {
        isT1 = t1;
    }


    public boolean isT2() {
        return isT2;
    }

    public void setT2(boolean t2) {
        isT2 = t2;
    }

    public boolean isYControlled() {
        return isXControlled;
    }

    public void setXControlled(boolean XControlled) {
        isXControlled = XControlled;
    }

    public boolean isColletClosed() {
        return isClampClosed;
    }

    public void setClampClosed(boolean clampClosed) {
        isClampClosed = clampClosed;
    }

    public boolean isTClose() {
        return tClose;
    }

    public void settClose(boolean tClose) {
        this.tClose = tClose;
    }

    public String toString(){
        switch (axis){
            case 'U':
                if(isXControlled) return "X ZABER";
                else return "X UVOLNI";
            case 'S':
                return "STOP";
            case 'K':
                if(isClampClosed) return "Clamp Close";
                else return "Clamp Open";
            case 'T':
                if(isT1 && isT2 && tClose) return "T1 + T2 ZATVOR";
                else if (isT1 && isT2 && !tClose) return "T1 + T2 OTVOR";
                else if (isT1 && !isT2 && tClose) return "T1 ZATVOR";
                else if (isT1 && !isT2 && !tClose) return "T1 OTVOR";
                else if (!isT1 && isT2 && tClose) return "T2 ZATVOR";
                else if (!isT1 && isT2 && !tClose) return "T2 OTVOR";
        }
        return "";
    }
}
