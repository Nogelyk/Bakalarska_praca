package com.example.tubebend;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class PreviewController {
    @FXML
    private TextArea textfield;
    private Stage stage;

    public void display(String s, Stage stage){
        this.stage = stage;
        this.textfield.setText(s);
    }

    @FXML
    private void closeWindow(){ stage.close(); }
}
