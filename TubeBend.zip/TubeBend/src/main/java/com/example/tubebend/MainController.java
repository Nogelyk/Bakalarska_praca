package com.example.tubebend;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;

public class MainController implements Initializable {

    public TreeView treeView;
    public TableView tableView;
    public Label bend1;
    public Label bend2;
    public Label bend3;
    public Label bend4;
    public Label bend5;
    public Button previewButton;
    public Button convertButton;
    private TreeItem rootItem;
    private ObservableList<Bend> bends = FXCollections.observableArrayList();
    private Stage popupStage;
    private String fileName;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        TableColumn<Bend, Double> y_posuv = new TableColumn<>("Y posuv");
        y_posuv.setPrefWidth(tableView.getPrefWidth()/8);
        y_posuv.setCellValueFactory(new PropertyValueFactory<>("y_main"));

        TableColumn<Bend, Double> b_natoc = new TableColumn<>("B natoc");
        b_natoc.setPrefWidth(tableView.getPrefWidth()/8);
        b_natoc.setCellValueFactory(new PropertyValueFactory<>("b_main"));

        TableColumn<Bend, Double> c_ohyb = new TableColumn<>("C ohyb");
        c_ohyb.setPrefWidth(tableView.getPrefWidth()/8);
        c_ohyb.setCellValueFactory(new PropertyValueFactory<>("c_main"));

        TableColumn<Bend, Double> y_abs = new TableColumn<>("Y abs");
        y_abs.setPrefWidth(tableView.getPrefWidth()/8);
        y_abs.setCellValueFactory(new PropertyValueFactory<>("y_abs"));

        TableColumn<Bend, Double> b_abs = new TableColumn<>("B abs");
        b_abs.setPrefWidth(tableView.getPrefWidth()/8);
        b_abs.setCellValueFactory(new PropertyValueFactory<>("b_abs"));

        TableColumn<Bend, Double> y_kor = new TableColumn<>("Y kor");
        y_kor.setPrefWidth(tableView.getPrefWidth()/8);
        y_kor.setCellValueFactory(new PropertyValueFactory<>("y_main_corr"));

        TableColumn<Bend, Double> b_kor = new TableColumn<>("B kor");
        b_kor.setPrefWidth(tableView.getPrefWidth()/8);
        b_kor.setCellValueFactory(new PropertyValueFactory<>("b_main_corr"));

        TableColumn<Bend, Double> c_kor = new TableColumn<>("C kor");
        c_kor.setPrefWidth((tableView.getPrefWidth()/8)-10);
        c_kor.setCellValueFactory(new PropertyValueFactory<>("c_main_corr"));

        tableView.getColumns().addAll(y_posuv, b_natoc, c_ohyb, y_abs, b_abs, y_kor, b_kor, c_kor);
        bends.add( new Bend("1. ohyb s uvol. posuvu",'u'));
        bends.add( new Bend("2. ohyb s otv. sklucovadla",'o'));
        bends.add( new Bend("3. ohyb s otv. sklucovadla",'o'));
        bends.add( new Bend("4. ohyb s uvol. posuvu",'u'));
        bends.add( new Bend("5. ohyb s uvol. posuvu",'u'));
        bends.add( new Bend("6. posledny ohyb kratkeho konca",'k'));
        convertToGcode();
        fillBlankCells();
        tableView.setItems(bends);

        rootItem = new TreeItem("Program name");
        for(Bend b:bends){
            TreeItem item = new TreeItem(b);
            for(Step s : b.getSteps()){
                TreeItem step = new TreeItem(s);
                item.getChildren().add(step);
            }
            rootItem.getChildren().add(item);
        }


        treeView.setOnMouseClicked(new EventHandler<MouseEvent>()
        {
            @Override
            public void handle(MouseEvent mouseEvent)
            {
                if(mouseEvent.getClickCount() == 2)
                {
                    try {
                        TreeItem<Step> step = (TreeItem<Step>) treeView.getSelectionModel().getSelectedItem();
                        popupStage = new Stage();
                        FXMLLoader popup;
                        if(step.getValue() instanceof PrimaryStep){
                            popup = new FXMLLoader(getClass().getResource("primary_properties.fxml"));
                        }
                        else{
                            popup = new FXMLLoader(getClass().getResource("secondary_properties.fxml"));
                        }
                        popupStage.setScene(new Scene(popup.load()));
                        PopupController controller = popup.getController();
                        step.valueProperty().set(controller.display(step.getValue(), popupStage, step));
                        popupStage.initModality(Modality.APPLICATION_MODAL);
                        popupStage.initOwner(treeView.getScene().getWindow());
                        popupStage.showAndWait();

                        for(Bend b:bends) {
                            b.actualize();
                        }
                        fillBlankCells();
                        tableView.refresh();

                    }
                    catch (Exception exception){
                        System.out.println(exception.getMessage());
                    }
                }
            }
        });

        treeView.setRoot(rootItem);
        treeView.setShowRoot(false);

    }

    private void refreshTreeView() {
        rootItem.getChildren().clear();
         for(Bend b:bends){
            b.actualize();
            TreeItem item = new TreeItem(b.toString());
            for(Step s : b.getSteps()){
                TreeItem st = new TreeItem(s);
                item.getChildren().add(st);
            }
            rootItem.getChildren().add(item);
        }
        fillBlankCells();
        tableView.refresh();
    }

    private void fillBlankCells(){
        Bend prve = bends.get(0);
        Bend akt;
        for(Step s: prve.getSteps()){
            if(s.isMainStep()){
                switch (s.getAxis()) {
                    case 'Y' -> prve.setY_abs(prve.getY_main());
                    case 'B' -> prve.setB_abs(prve.getB_main());
                }
            }
        }


        for(int i = 1; i < bends.size(); i++){
            Bend pred = bends.get(i-1);
            akt = bends.get(i);
            for(Step s: akt.getSteps()){
                if(s instanceof PrimaryStep && s.isMainStep()){
                    switch (s.getAxis()){
                        case 'Y':
                            if(s.isAbs()){
                                akt.setY_abs(akt.getY_main());
                                akt.setY_main(akt.getY_main() - pred.getY_abs());
                            }
                            else{
                                akt.setY_abs(pred.getY_abs()+akt.getY_main());
                            }
                            break;
                        case 'B':
                            if(s.isAbs()){
                                akt.setB_abs(akt.getB_main());
                                akt.setB_main(akt.getB_main() - pred.getB_abs());
                            }
                            else{
                                akt.setB_abs(pred.getB_abs()+akt.getB_main());
                            }
                            break;

                    }
                }
            }
        }
    }
    @FXML
    private void handleDragDetection(MouseEvent event){
        Dragboard db = null;
        ClipboardContent cb = new ClipboardContent();
        switch (((Control)event.getSource()).getId()){
            case "bend1" -> {
                db = bend1.startDragAndDrop(TransferMode.ANY);
                cb.putString("pres_hor");
            }
            case "bend2" -> {
                db = bend2.startDragAndDrop(TransferMode.ANY);
                cb.putString("pres_dol");
            }
            case "bend3" -> {
                db = bend3.startDragAndDrop(TransferMode.ANY);
                cb.putString("otv");
            }
            case "bend4" -> {
                db = bend4.startDragAndDrop(TransferMode.ANY);
                cb.putString("uvol");
            }
            case "bend5" -> {
                db = bend5.startDragAndDrop(TransferMode.ANY);
                cb.putString("ohyb_kk");
            }
            case "t" -> {
                db = bend3.startDragAndDrop(TransferMode.ANY);
                cb.putString("t");
            }
            case "x" -> {
                db = bend4.startDragAndDrop(TransferMode.ANY);
                cb.putString("x");
            }
            case "y" -> {
                db = bend5.startDragAndDrop(TransferMode.ANY);
                cb.putString("y");
            }
            case "z" -> {
                db = bend3.startDragAndDrop(TransferMode.ANY);
                cb.putString("z");
            }
            case "clamp" -> {
                db = bend4.startDragAndDrop(TransferMode.ANY);
                cb.putString("clamp");
            }
            case "c" -> {
                db = bend5.startDragAndDrop(TransferMode.ANY);
                cb.putString("c");
            }
            case "b" -> {
                db = bend3.startDragAndDrop(TransferMode.ANY);
                cb.putString("b");
            }
            case "uvol" -> {
                db = bend4.startDragAndDrop(TransferMode.ANY);
                cb.putString("y_uvol");
            }
            case "stop" -> {
                db = bend5.startDragAndDrop(TransferMode.ANY);
                cb.putString("stop");
            }
        }
        if (db != null) {
            db.setContent(cb);
        }
        event.consume();
    }

    @FXML
    private void handleDragOver(DragEvent event){
       if(event.getDragboard().hasString()){
           event.acceptTransferModes(TransferMode.ANY);
       }
    }

    @FXML
    private void handleDragDropped(DragEvent event){

        String str = event.getDragboard().getString();
        switch (str){
            case "pres_hor" -> bends.add(new Bend("5. presun do hor. nastroja", 'h'));

            case "pres_dol" -> bends.add(new Bend("5. presun do dol. nastroja", 'd'));

            case "otv" -> bends.add(new Bend("5. ohyb s otv. sklucovadla", 'o'));

            case "uvol" -> bends.add(new Bend("5. ohyb s uvol.posuvu", 'u'));

            case "ohyb_kk" -> bends.add(new Bend("5. posledny ohyb kratkeho konca", 'k'));

            case "t" -> new SecondaryStep('T', true, false,0,0,"");

            case "x" -> new PrimaryStep('X',0,0,true,100,true,0,0,false,"");

            case "y" -> new PrimaryStep('Y', 0,0,true, 100, true, 0, 0,true, "");

            case "z" -> new PrimaryStep('Z',0,0,true,100,true,0,0,false,"");

            case "clamp" -> new SecondaryStep('K',false,false,0,0,"");

            case "c" -> new PrimaryStep('C', 0,0,true, 100, false, 0, 0,true, "ohyb");

            case "b" -> new PrimaryStep('B', 0,0,true, 100, false, 0, 0,true, "");

            case "y_uvol" -> new SecondaryStep('U',true,false,0,0,"");

            case "stop" -> new SecondaryStep('S',true,false,0,0,"");

        }
        refreshTreeView();
    }
    @FXML
    private void handlePreviewAction(){
        try {
            popupStage = new Stage();
            FXMLLoader popup = new FXMLLoader(getClass().getResource("preview_window.fxml"));
            popupStage.setScene(new Scene(popup.load()));
            PreviewController controller = popup.getController();
            controller.display(convertToGcode(), popupStage);
            popupStage.initModality(Modality.APPLICATION_MODAL);
            popupStage.initOwner(treeView.getScene().getWindow());
            popupStage.showAndWait();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    @FXML
    private void convertToFile(){
        fileName = rootItem.getValue().toString() + ".mpf";
        try{
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileName));
            bw.write(convertToGcode());
            bw.flush();
            bw.close();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("Subor " + fileName + " bol úspešne vytvorený");
            alert.setContentText("C:\\Users\\user\\IdeaProjects\\TubeBend\\" + fileName);
            alert.showAndWait().ifPresent(rs ->{
                if(rs == ButtonType.OK) System.out.println("Pressed OK");
            });
        }catch (Exception e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Vytvorenie súboru nebolo úspešné");
            alert.setContentText(e.getMessage());
            alert.showAndWait().ifPresent(rs ->{
                if(rs == ButtonType.OK) System.out.println("Pressed OK");
            });
        }
    }

    public String convertToGcode(){
        String vysledok = "";
        double startingPos = 2000;
        int i = 1;
        int necakat = 0;
        vysledok += "R150=10000 \n";
        vysledok += "R151=35000 \n";
        vysledok += "R1=" + startingPos + " \n";
        vysledok += "M41 M43 M45 \n";
        vysledok += "G90 G0 Y=R1 \n";
        vysledok += "G90 G0 C=0 \n";
        vysledok += "G90 G0 B=0 \n";
        for(Bend b:bends){
            vysledok += "N" + i + "; " + b.toString() + "\n";
            i++;
            for(Step s:b.getSteps()){
                if(s.getWaitBefore() > 0) vysledok += "G4 F=" + s.getWaitBefore() + " \n";
                switch (s.getAxis()){
                    case 'Y' -> {
                        if(s.isAbs()){
                            switch (necakat){
                                case 0 -> vysledok += "G90 G01 F=R151*" + s.getSpeed() + " Y=" + (startingPos - (s.getPos() + s.getCorr())) + " ";
                                case 1 -> vysledok += " Y=AC(" + (startingPos - (s.getPos() + s.getCorr())) + ") ";
                                case 2 -> vysledok += " Y=" + (startingPos - (s.getPos() + s.getCorr())) + " ";
                            }
                        }else{
                            switch (necakat){
                                case 0 -> vysledok += "G91 G01 F=R151*" + s.getSpeed() + " Y=-" + (s.getPos()+s.getCorr()) + " ";
                                case 1 -> vysledok += " Y=-" + (s.getPos()+s.getCorr()) + " ";
                                case 2 -> vysledok += " Y=IC(-" + (s.getPos()+s.getCorr()) + ") ";
                            }
                        }

                    }

                    case 'X' -> {
                        if(necakat == 0) vysledok += "G91 G01 F=R150*" + s.getSpeed() + " X=" + (s.getPos() + s.getCorr()) + " ";
                    }

                    case 'Z' -> {
                        if(necakat == 0) vysledok += "G91 G01 F=R150*" + s.getSpeed() + " Z=" + (s.getPos() + s.getCorr() + " ");
                    }

                    case 'B' -> {
                        if(s.isAbs()){
                            switch (necakat){
                                case 0 -> vysledok += "G90 G01 F=R150*" + s.getSpeed() + " B=" + (s.getPos() + s.getCorr()) + " ";
                                case 1 -> vysledok += " B=AC(" + (s.getPos() + s.getCorr()) + ") ";
                                case 2 -> vysledok += " B=" + (s.getPos() + s.getCorr()) + " ";
                            }
                        } else {
                            switch (necakat){
                                case 0 -> vysledok += "G91 G01 F=R150*" + s.getSpeed() + " B=" + (s.getPos() + s.getCorr()) + " ";
                                case 1 -> vysledok += " B=" + (s.getPos() + s.getCorr()) + " ";
                                case 2 -> vysledok += " B=IC(" + (s.getPos() + s.getCorr()) + ") ";
                            }
                        }
                    }

                    case 'C' -> {
                        if(s.isAbs()){
                            if(s.getPos() == 0) vysledok += "G90 G01 F=R150*" + s.getSpeed() + " C=0 ";
                            else{
                                switch (necakat){
                                    case 0 -> {
                                        vysledok += "G90 G01 F=R150*" + s.getSpeed() + " C=" + (s.getPos() + s.getCorr() - 1) + " M44 G641 \n";
                                        vysledok += "G90 G01 F=R150*" + s.getSpeed() + " C=" + (s.getPos() + s.getCorr()) + " M44 M73 G60 ";
                                    }
                                    case 1 -> {
                                        vysledok += " C=AC(" + (s.getPos() + s.getCorr() - 1) + ") M44 G641 \n";
                                        vysledok += " C=" + (s.getPos() + s.getCorr()) + " M44 M73 G60 ";
                                    }
                                    case 2 -> {
                                        vysledok += " C=" + (s.getPos() + s.getCorr() - 1) + " M44 G641 \n";
                                        vysledok += " C=" + (s.getPos() + s.getCorr()) + " M44 M73 G60 ";
                                    }

                                }
                            }
                        } else {
                            switch (necakat){
                                case 0 -> {
                                    vysledok += "G91 G01 F=R150*" + s.getSpeed() + " C=" + (s.getPos() + s.getCorr() - 1) + " M44 G641 \n";
                                    vysledok += "G91 G01 F=R150*" + s.getSpeed() + " C=1 M44 M73 G60 ";
                                }
                                case 1 -> {
                                    vysledok += " C=" + (s.getPos() + s.getCorr() - 1) + " M44 G641 \n";
                                    vysledok += " C=1 M44 M73 G60 ";
                                }
                                case 2 -> {
                                    vysledok += "G91 G01 F=R150*" + s.getSpeed() + " C=IC(" + (s.getPos() + s.getCorr() - 1) + ") M44 G641 \n";
                                    vysledok += "G91 G01 F=R150*" + s.getSpeed() + " C=1 M44 M73 G60 ";
                                }
                            }
                        }
                    }

                    case 'K' -> {
                        if(s.isColletClosed()) vysledok += "M60 ";
                        else vysledok += "M61 ";
                    }

                    case 'U' -> {
                        if(s.isYControlled()) vysledok += "M71 ";
                        else vysledok += "M70 ";
                    }

                    case 'T' -> {
                        if(s.isTClose()){
                            if(s.isT1() && s.isT2()) vysledok += "M40 M42 ";
                            else if(s.isT1()) vysledok += "M40 ";
                            else if(s.isT2()) vysledok += "M42 ";
                        }else {
                            if(s.isT1() && s.isT2()) vysledok += "M41 M43 M45 ";
                            else if(s.isT1()) vysledok += "M41 M45 ";
                            else if(s.isT2()) vysledok += "M43 M45 ";
                        }
                    }
                }
                if(s.getWaitAfter() > 0) vysledok += "G4 F=" + s.getWaitAfter() + " ";
                if(s.isNoWait()){
                    if(s.isAbs()) necakat = 2;
                    else necakat = 1;

                } else {
                    vysledok += "\n";
                    necakat = 0;
                }
            }
        }
        return vysledok;
    }
}
