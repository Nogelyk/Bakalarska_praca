package com.example.tubebend;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;


public class PopupController {

    private Step step;
    private Stage stage;
    @FXML
    private Label type;
    @FXML
    private TextField wait;
    @FXML
    private TextField pos;
    @FXML
    private TextField corr;
    @FXML
    private TextField speed;
    @FXML
    private TextField wait_after;
    @FXML
    private TextField comment;
    @FXML
    private RadioButton abs;
    @FXML
    private RadioButton rel;
    @FXML
    private RadioButton open;
    @FXML
    private RadioButton close;
    @FXML
    private CheckBox no_wait;
    @FXML
    private CheckBox t1;
    @FXML
    private CheckBox t2;
    private char axis;
    private boolean isMain;
    private TreeItem steppppp;


    public Step display(Step s, Stage stage, TreeItem step){
        this.step = s;
        this.stage = stage;
        this.steppppp = step;
        if(s instanceof PrimaryStep) onPrimaryStep();
        else if(s instanceof SecondaryStep) onSecondaryStep();
        return this.step;

    }

    public void onPrimaryStep(){
        switch (step.getAxis()){
            case 'X':
                abs.setText("VON");
                rel.setText("DNU");
                break;
            case 'Z':
                abs.setText("HORE");
                rel.setText("DOLE");
                break;
        }
        axis = step.getAxis();
        isMain = step.isMainStep();
        type.setText("Phohyb v smere: " + step.getAxis());
        wait.setText(step.getWaitBefore() + "");
        pos.setText(step.getPos() + "");
        corr.setText(step.getCorr() + "");
        speed.setText(step.getSpeed() + "");
        if(step.isAbs()) abs.setSelected(true);
        else rel.setSelected(true);
        wait_after.setText(step.getWaitAfter() + "");
        if(step.isNoWait()) no_wait.setSelected(true);
        else no_wait.setSelected(false);
        comment.setText(step.getNote());

    }

    public void onSecondaryStep(){
        switch (step.getAxis()){
            case 'C':
                t1.setVisible(false);
                t2.setVisible(false);
                if(step.isColletClosed()) close.setSelected(true);
                else open.setSelected(true);
                break;
            case 'S':
                t1.setVisible(false);
                t2.setVisible(false);
                open.setVisible(false);
                close.setSelected(false);
                break;
            case 'X':
                t1.setVisible(false);
                t2.setVisible(false);
                open.setText("Zaber");
                close.setText("Uvolni");
                if(step.isYControlled()) open.setSelected(true);
                else close.setSelected(true);
                break;
            case 'T':
                if(step.isT1()) t1.setSelected(true);
                else t1.setSelected(false);
                if(step.isT2()) t2.setSelected(true);
                else t2.setSelected(false);
                if(step.isTClose()) close.setSelected(true);
                else open.setSelected(true);
        }
        axis = step.getAxis();
        type.setText("Phohyb v smere: " + step.getAxis());
        wait.setText(step.getWaitBefore() + "");
        wait_after.setText(step.getWaitAfter() + "");


        if(step.isNoWait()) no_wait.setSelected(true);
        else no_wait.setSelected(false);
        comment.setText(step.getNote());

    }

    @FXML
    protected void cancelButtonClick(){
        stage.close();
    }

    @FXML
    protected void okButtonClick(){

        if(step instanceof PrimaryStep) {
            step.setAxis(axis);
            step.setPos(Double.parseDouble(pos.getText()));
            step.setCorr(Double.parseDouble(corr.getText()));
            step.setAbs(abs.isSelected());
            step.setSpeed(Double.parseDouble(speed.getText()));
            step.setNoWait(no_wait.isSelected());
            step.setWaitBefore(Double.parseDouble(wait.getText()));
            step.setWaitAfter(Double.parseDouble(wait_after.getText()));
            step.setNote(comment.getText());
            step.setMainStep(isMain);
            steppppp.setValue(null);
            steppppp.setValue(step);

        }
        else{
            step.setAxis(axis);
            switch (axis){
                case 'X':
                    if(open.isSelected()) step.setXControlled(true);
                    else step.setXControlled(false);
                    break;
                case 'S':
                    step.setStop(true);
                    break;
                case 'C':
                    if(open.isSelected()) step.setClampClosed(false);
                    else step.setClampClosed(true);
                    break;
                case 'T':
                    if(t1.isSelected()) step.setT1(true);
                    else step.setT1(false);
                    if(t2.isSelected()) step.setT2(true);
                    else step.setT2(false);
                    if(open.isSelected()) step.settClose(false);
                    else step.settClose(true);
                    break;
            }
            step.setNoWait(no_wait.isSelected());
            step.setWaitBefore(Double.parseDouble(wait.getText()));
            step.setWaitAfter(Double.parseDouble(wait_after.getText()));
            step.setNote(comment.getText());
            steppppp.setValue(null);
            steppppp.setValue(step);

        }
        stage.close();



    }

}
