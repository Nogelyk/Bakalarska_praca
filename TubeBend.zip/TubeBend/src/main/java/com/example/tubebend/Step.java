package com.example.tubebend;

public class Step {

    protected static int id = 1;
    private int bend_id;
    protected char axis;
    protected double pos = 0;
    protected double corr = 0;
    protected boolean isAbs;
    protected double speed = 0;
    protected boolean noWait = true;
    protected double waitBefore = 0;
    protected double waitAfter = 0;
    protected String note = "";
    protected boolean mainStep = false;
    private boolean isStop;
    private boolean isXControlled;
    private boolean isClampClosed;
    private boolean tClose;
    private boolean isT1;
    private boolean isT2;


    public Step(char axis, boolean noWait, double waitBefore, double waitAfter, String note) {
        this.bend_id = id++;
        this.axis = axis;
        this.noWait = noWait;
        this.waitBefore = waitBefore;
        this.waitAfter = waitAfter;
        this.note = note;
    }

    public char getAxis() {
        return axis;
    }

    public void setAxis(char axis) {
        this.axis = axis;
    }

    public double getPos() {
        return pos;
    }

    public void setPos(double pos) {
        this.pos = pos;
    }

    public double getCorr() {
        return corr;
    }

    public void setCorr(double corr) {
        this.corr = corr;
    }

    public boolean isAbs() {
        return isAbs;
    }

    public void setAbs(boolean abs) {
        isAbs = abs;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public boolean isNoWait() {
        return noWait;
    }

    public void setNoWait(boolean noWait) {
        this.noWait = noWait;
    }

    public double getWaitBefore() {
        return waitBefore;
    }

    public void setWaitBefore(double waitBefore) {
        this.waitBefore = waitBefore;
    }

    public double getWaitAfter() {
        return waitAfter;
    }

    public void setWaitAfter(double waitAfter) {
        this.waitAfter = waitAfter;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public boolean isMainStep() {
        return mainStep;
    }

    public void setMainStep(boolean mainStep) {
        this.mainStep = mainStep;
    }

    public int getBend_id() {
        return bend_id;
    }

    public boolean isStop() {
        return isStop;
    }

    public void setStop(boolean stop) {
        isStop = stop;
    }

    public boolean isYControlled() {
        return isXControlled;
    }

    public void setXControlled(boolean XControlled) {
        isXControlled = XControlled;
    }

    public boolean isColletClosed() {
        return isClampClosed;
    }

    public void setClampClosed(boolean clampClosed) {
        isClampClosed = clampClosed;
    }

    public boolean isTClose() {
        return tClose;
    }

    public void settClose(boolean tClose) {
        this.tClose = tClose;
    }

    public boolean isT1() {
        return isT1;
    }

    public void setT1(boolean t1) {
        isT1 = t1;
    }

    public boolean isT2() {
        return isT2;
    }

    public void setT2(boolean t2) {
        isT2 = t2;
    }
}
