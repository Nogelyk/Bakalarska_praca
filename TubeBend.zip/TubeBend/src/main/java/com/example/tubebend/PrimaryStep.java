package com.example.tubebend;

public class PrimaryStep extends Step{

    private double pos = 0;
    private double corr = 0;
    private boolean isAbs;
    private double speed = 0;
    private boolean mainStep = false;



    public PrimaryStep(char axis, double pos, double corr, boolean isAbs, double speed, boolean noWait, double waitBefore, double waitAfter, boolean mainStep, String note) {
        super(axis, noWait, waitBefore, waitAfter, note);
        this.pos = pos;
        this.corr = corr;
        this.isAbs = isAbs;
        this.speed = speed;
        this.mainStep = mainStep;
    }

    public double getPos() {
        return pos;
    }

    public void setPos(double pos) {
        this.pos = pos;
    }

    public double getCorr() {
        return corr;
    }

    public void setCorr(double corr) {
        this.corr = corr;
    }

    public boolean isAbs() {
        return isAbs;
    }

    public void setAbs(boolean abs) {
        isAbs = abs;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public boolean isMainStep() {
        return mainStep;
    }

    public void setMainStep(boolean mainStep) {
        this.mainStep = mainStep;
    }

    public String toString(){
        if(corr == 0 && isAbs && axis == 'X') return this.axis + " " + pos + " VON";
        else if(corr == 0 && !isAbs && axis == 'X') return this.axis + " " + pos + " DNU";
        else if(corr == 0 && isAbs && axis == 'Z') return this.axis + " " + pos + " HORE";
        else if(corr == 0 && !isAbs && axis == 'Z') return this.axis + " " + pos + " DOLE";
        else if(corr == 0 && isAbs) return this.axis + " " + pos + " ABS";
        else if(corr == 0 && !isAbs) return  this.axis + " " + pos + " REL";
        else if(isAbs) return this.axis + " " + pos + "+" + corr + " ABS";
        else return this.axis + " " + pos + "+" + corr + " REL";
    }
}
